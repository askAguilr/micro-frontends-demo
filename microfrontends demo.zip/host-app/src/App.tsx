import {lazy, Suspense} from 'react';
const GuestReactApp = lazy(() => import('guestReactApp/GuestReactApp') as any);
import AngularjsApp from 'guestAngularjsApp/GuestAngularApp';

// @ts-ignore
console.log('AngularjsApp', AngularjsApp);


function App() {
  return (
    <div className="App">
      <div className="card">
        This is the host App
        <Suspense fallback={<div>Loading...</div>}>
          <GuestReactApp />
        </Suspense>
        <br />
        --separator--
        <br />
        <Suspense fallback={<div>Loading...</div>}>
        </Suspense>
      </div>
    </div>
  )
}

export default App;
