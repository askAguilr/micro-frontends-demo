/// <reference types="vite/client" />
declare module 'guestReactApp/*' {}
declare module 'guestAngularjsApp/*' {}